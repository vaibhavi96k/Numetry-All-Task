import java.io.*;

public class ByteArrayInputOutput {
	public static void main(String[] args) {
		byte[] data = "Hello, I am Avantika Jambhale".getBytes();
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        // Reading from ByteArrayInputStream and writing to ByteArrayOutputStream
        int byteRead;
        while ((byteRead = byteArrayInputStream.read()) != -1) {
            byteArrayOutputStream.write(byteRead);
        }

        // Displaying the result from ByteArrayOutputStream
        System.out.println("ByteArrayOutputStream Result: " + byteArrayOutputStream.toString());
	}
}
