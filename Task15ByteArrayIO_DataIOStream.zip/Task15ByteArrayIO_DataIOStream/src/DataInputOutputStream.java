import java.io.*;

public class DataInputOutputStream {
	public static void main(String[] args) {
        // Specify the file path
        String filePath = "datafile.dat";

        // Writing data using DataOutputStream
        try (DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(filePath))) {
            dataOutputStream.writeUTF("Hello, Devlopers!!!!!");
            dataOutputStream.writeInt(42);
            dataOutputStream.writeDouble(3.14);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Reading data using DataInputStream
        try (DataInputStream dataInputStream = new DataInputStream(new FileInputStream(filePath))) {
            String message = dataInputStream.readUTF();
            int intValue = dataInputStream.readInt();
            double doubleValue = dataInputStream.readDouble();

            // Displaying the results
            System.out.println("DataInputStream Result:");
            System.out.println("Message: " + message);
            System.out.println("Int Value: " + intValue);
            System.out.println("Double Value: " + doubleValue);
        } catch (IOException e) {
            e.printStackTrace();
        }
}
}
