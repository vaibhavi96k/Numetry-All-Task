import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;

public class FileDatabaseCRUD {

    private static final String DB_URL = "jdbc:mysql://localhost:3307/file_database";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        try {
            // Connect to the database
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Create tables if they don't exist
            createTables(connection);

            // Insert file into database
            File file = new File("C:/Users/Dell/Desktop/Numetry internship/example.txt");
            insertFile(connection, file);

            // Read file from database
            File retrievedFile = getFile(connection, 1);
            System.out.println("Retrieved file: " + retrievedFile.getName());

            // Update file in database
            File updatedFile = new File("C:/Users/Dell/Desktop/Numetry internship/updated_example.txt");
            updateFile(connection, 1, updatedFile);

            // Delete file from database
            deleteFile(connection, 1);

            // Close the connection
            connection.close();
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }

    private static void createTables(Connection connection) throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeUpdate("CREATE TABLE IF NOT EXISTS files (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255), content LONGBLOB)");
        statement.close();
    }

    private static void insertFile(Connection connection, File file) throws SQLException, IOException {
        String query = "INSERT INTO files (name, content) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, file.getName());
            try (FileInputStream inputStream = new FileInputStream(file)) {
                preparedStatement.setBinaryStream(2, inputStream, (int) file.length());
                preparedStatement.executeUpdate();
            }
        }
    }

    private static File getFile(Connection connection, int fileId) throws SQLException, IOException {
        String query = "SELECT name, content FROM files WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, fileId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    String fileName = resultSet.getString("name");
                    try (FileOutputStream outputStream = new FileOutputStream(fileName)) {
                        byte[] buffer = new byte[1024];
                        InputStream inputStream = resultSet.getBinaryStream("content");
                        while (inputStream.read(buffer) > 0) {
                            outputStream.write(buffer);
                        }
                    }
                    return new File(fileName);
                }
            }
        }
        return null;
    }

    private static void updateFile(Connection connection, int fileId, File updatedFile) throws SQLException, IOException {
        String query = "UPDATE files SET name = ?, content = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, updatedFile.getName());
            try (FileInputStream inputStream = new FileInputStream(updatedFile)) {
                preparedStatement.setBinaryStream(2, inputStream, (int) updatedFile.length());
                preparedStatement.setInt(3, fileId);
                preparedStatement.executeUpdate();
            }
        }
    }

    private static void deleteFile(Connection connection, int fileId) throws SQLException {
        String query = "DELETE FROM files WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, fileId);
            preparedStatement.executeUpdate();
        }
    }
}
