import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ImageDatabaseCRUD {

    private static final String DB_URL = "jdbc:mysql://localhost:3307/image_database";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    public static void main(String[] args) {
        try {
            // Connect to the database
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Insert image into database
            File imageFile = new File("C:/Users/Dell/Pictures/time-mg image.png");
            insertImage(connection, imageFile);

            // Close the connection
            connection.close();
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }

    private static void insertImage(Connection connection, File imageFile) throws SQLException, IOException {
        String query = "INSERT INTO images (name, content) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, imageFile.getName());
            try (FileInputStream inputStream = new FileInputStream(imageFile)) {
                preparedStatement.setBinaryStream(2, inputStream, (int) imageFile.length());
                preparedStatement.executeUpdate();
            }
        }
    }
}
