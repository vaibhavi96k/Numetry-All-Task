package special_number;

import java.util.*;

public class factorialNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Entre number = ");
		int n = sc.nextInt();
		int fact =1;
		for(int i=1;i<=n;i++) {
			fact = fact*i;
		}
		System.out.println("Factorial of "+n+" is = "+fact);
	}
}
