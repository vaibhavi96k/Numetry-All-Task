package special_number;
import java.util.*;
public class primeNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Entre number = ");
		int x = sc.nextInt();
		int count =0;
		if(x==0 || x==1) {
			System.out.println("Number is not prime = "+x);
		}
		else if(x==2) {
			System.out.println("Number is prime = "+x);
		}
		else if(x>2) {
			for(int i=2; i<x; i++) {
				if(x%i==0) {
					count =1 ;
				}	
			}
			if(count==1) {
				System.out.println("Number is not prime = "+x);
			}
			if(count == 0) {
				System.out.println("Number is prime = "+x);
			}
		}
	}
}
