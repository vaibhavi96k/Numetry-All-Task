package special_number;
import java.util.*;
public class palindromeNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Entre number = ");
		int n = sc.nextInt();
		int x;
		int m=n;
		int s =0;
		while(n!=0) {
			x = n%10;
			s = (s*10)+x;
			n = n/10;
		}
		if(m==s) {
			System.out.println("Given number is palindrome = "+m);
		}
		else {
			System.out.println("Given number is not a palindrome = "+m);
		}
	}
}
