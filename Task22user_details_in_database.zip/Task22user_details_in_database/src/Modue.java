import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Modue {
    private String username;
    private String email;
    private String pass;

    // Constructor
    public Modue(String username, String email, String pass) {
        this.username = username;
        this.email = email;
        this.pass = pass;
    }

    // Method to save user details to the database
    public void saveToDatabase() {
        // JDBC connection parameters
        String url = "jdbc:mysql://localhost:3307/moduedb";
        String user = "root";
        String password = "root";

        // SQL query to insert user details
        String sql = "INSERT INTO student (username, email, pass) VALUES (?, ?, ?)";

        try (
            // Establishing a connection
            Connection connection = DriverManager.getConnection(url, user, password);
            // Creating a prepared statement
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ) {
            // Setting values for the prepared statement
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, pass);

            // Executing the query
            preparedStatement.executeUpdate();

            System.out.println("User details saved to the database.");
        } catch (SQLException e) {
            System.err.println("Error saving user details: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        // Example usage
        Modue user = new Modue("Manasi_Gaikwad", "mg@gmail.com.com", "pass123");
    	
        user.saveToDatabase();
    }
}
