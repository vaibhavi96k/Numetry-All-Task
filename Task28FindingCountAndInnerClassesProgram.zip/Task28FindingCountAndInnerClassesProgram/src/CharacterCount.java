import java.util.*;
public class CharacterCount {
    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
    	System.out.print("Enter a string : ");
        String inputString = sc.nextLine();

        int alphabetCount = 0;
        int digitCount = 0;
        int specialSymbolCount = 0;

        for (int i = 0; i < inputString.length(); i++) {
            char ch = inputString.charAt(i);

            if (Character.isLetter(ch)) {
                alphabetCount++;
            }
            
            else if (Character.isDigit(ch)) {
                digitCount++;
            }
            
            else {
                specialSymbolCount++;
            }
        }

        System.out.println("Alphabets: " + alphabetCount);
        System.out.println("Digits: " + digitCount);
        System.out.println("Special Symbols: " + specialSymbolCount);
    }
}
