// Outer class
public class OuterClass {
    
    private int outerField;

    public OuterClass(int outerField) {
        this.outerField = outerField;
    }

    public class InnerClass {
        public void display() {
            System.out.println("Value of outerField: " + outerField);
        }
    }

    public void useInnerClass() {
        InnerClass inner = new InnerClass();
        inner.display();
    }

    public static void main(String[] args) {
        
        OuterClass outer = new OuterClass(10);
        outer.useInnerClass();
    }
}
