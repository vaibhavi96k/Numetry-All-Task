
public class allstringmethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "jjmcoe";
		System.out.println("Lower Letter :"+str.toLowerCase());
		System.out.println("Upper Letter :"+str.toUpperCase());
		System.out.println(str.trim());
		System.out.println(str.startsWith("j"));
		System.out.println(str.endsWith("e"));
		System.out.println(str.charAt(0));
		System.out.println(str.charAt(3));
		System.out.println(str.length());
		
	}

}
