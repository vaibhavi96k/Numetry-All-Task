
public class ConvertStringToStringbuilderStringbuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String v = "Vaibhavi";
		System.out.println("Normal : "+v);
		//convert string into stringbuilder
		StringBuilder s1 = new StringBuilder(v);
		s1.reverse();
		System.out.println("Reverse the string :"+s1);
		//convert string into stringbuffer
		StringBuffer s2 = new StringBuffer(v);
		s2.append("Gaikwad");
		System.out.println("append : "+s2);
	}

}
