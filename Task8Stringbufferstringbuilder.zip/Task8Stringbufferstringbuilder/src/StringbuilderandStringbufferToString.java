
public class StringbuilderandStringbufferToString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer s1 = new StringBuffer("Vaibhavi Gaikwad");
		String s = s1.toString();
		
		System.out.println(s);
		
		StringBuilder s2 = new StringBuilder("Ranajit Gaikwad");
		String ss = s2.toString();
		
		System.out.println(ss);

	}

}
