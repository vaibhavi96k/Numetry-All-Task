import java.util.*;
public class vectormethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> animals= new Vector<>();
        animals.add("Dog");
        animals.add("Horse");
        animals.add("Cat");

        String element = animals.get(2);
        System.out.println("Element at index 2: " + element);

        Iterator<String> iterate = animals.iterator();
        System.out.print("Vector: ");
        while(iterate.hasNext()) {
            System.out.print(iterate.next());
            System.out.print(", ");
            
        System.out.println(animals.capacity());
        System.out.println(animals.elementAt(1));
        System.out.println(animals.firstElement());
        System.out.println(animals.lastElement());
        System.out.println(animals.indexOf("Horse"));
        System.out.println(animals.isEmpty());
	}
   }
}
