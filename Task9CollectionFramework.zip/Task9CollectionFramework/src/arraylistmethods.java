import java.util.*;

public class arraylistmethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> languages = new ArrayList<>();  //stack 
	    languages.add("Java");
	    languages.add("Python");
	    languages.add("Swift");
	    languages.add("R");
	    languages.add("CPP");
	    languages.add("C");
	    
	    System.out.println("ArrayList: " + languages);
	    System.out.println(languages.isEmpty());
	    System.out.println(languages.indexOf("C"));
	    System.out.println(languages.addAll(languages));
	    System.out.println(languages.isEmpty());
	    System.out.println(languages.size());
	    System.out.println(languages.remove(5));
	    System.out.println(languages.lastIndexOf(languages));
	    System.out.println(languages.hashCode());
	}
}
