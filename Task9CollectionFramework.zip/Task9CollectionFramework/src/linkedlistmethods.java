import java.util.*;
public class linkedlistmethods {

	public static void main(String[] args) {
		
		LinkedList<String> animals = new LinkedList<>();

	    animals.add("Dog");
	    animals.add("Cat");
	    animals.add("Cow");
	    System.out.println("LinkedList: " + animals);
	    System.out.println(animals.isEmpty());
	    System.out.println(animals.contains("Cow"));
	    System.out.println(animals.get(1));
	    System.out.println(animals.getFirst());
	    System.out.println(animals.getLast());
	    System.out.println(animals.hashCode());
	    System.out.println(animals.indexOf("Cat"));
	    System.out.println(animals.peekFirst());
	    System.out.println(animals.peekLast());
	}

}
