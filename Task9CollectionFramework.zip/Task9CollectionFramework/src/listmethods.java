import java.util.*;
public class listmethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List<String> list=new ArrayList<String>();  
		 //Adding elements in the List  
		 list.add("Mango");  
		 list.add("Apple");  
		 list.add("Banana");  
		 list.add("Grapes");  
		 //Iterating the List element using for-each loop  
		 for(String fruit:list)  
		  System.out.println(fruit); 
		 System.out.println(list.indexOf("Apple"));
		 System.out.println(list.get(2));
		 System.out.println(list.remove(3));
		 System.out.println(list.isEmpty());
		 System.out.println(list.lastIndexOf(list));
		 
		 List<Integer> l = new ArrayList<Integer>();
		 l.add(1);
		 l.add(2);
		 l.add(3);
		 System.out.println(l);
		 System.out.println(l.size());
		 System.out.println(l.hashCode());

	}

}
