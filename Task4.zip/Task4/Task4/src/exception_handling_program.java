import java.util.Scanner;
public class exception_handling_program {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        try {
	            System.out.print("Enter an integer: ");
	            int number = scanner.nextInt();

	            int result = 10 / number;

	            System.out.println("Result of division: " + result);
	        } catch (ArithmeticException e) {
	            System.out.println("Error: " + e.getMessage());
	        } catch (Exception e) {
	            System.out.println("An unexpected error occurred: " + e.getMessage());
	        } finally {
	            System.out.println("This block is always runs.");
	            scanner.close();
	        }

	        System.out.println("Program continues after exception handling.");
	    }

}
