import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
public class functional_programming_program {
	public static void main(String[] args) {
        Runnable runnable = () -> System.out.println("Hello, I'm a lambda expression!");
        new Thread(runnable).start();

        List<String> programmingLanguages = Arrays.asList("Java", "Python", "JavaScript", "Ruby", "C#");

        List<String> filteredLanguages = programmingLanguages.stream()
                .filter(language -> language.startsWith("J"))
                .collect(Collectors.toList());

        System.out.println("Filtered languages: " + filteredLanguages);

        MyFunctionalInterface<String> converter = s -> s.toUpperCase();

        String result = converter.convert("functional programming");
        System.out.println("Converted string: " + result);
    }
}
@FunctionalInterface
interface MyFunctionalInterface<T> {
    T convert(T input);
}
