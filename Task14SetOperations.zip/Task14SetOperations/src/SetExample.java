import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetExample {
    public static void main(String[] args) {
        // Creating a HashSet
        Set<String> hashSet = new HashSet<>();

        // Adding elements to the HashSet
        hashSet.add("Apple");
        hashSet.add("Banana");
        hashSet.add("Orange");
        hashSet.add("Apple"); // Duplicate element, won't be added

        // Displaying elements of the HashSet
        System.out.println("HashSet elements: " + hashSet);

        // Creating a TreeSet
        Set<String> treeSet = new TreeSet<>();

        // Adding elements to the TreeSet
        treeSet.add("Zebra");
        treeSet.add("Lion");
        treeSet.add("Elephant");
        treeSet.add("Lion"); // Duplicate element, won't be added

        // Displaying elements of the TreeSet
        System.out.println("TreeSet elements: " + treeSet);
    }
}
