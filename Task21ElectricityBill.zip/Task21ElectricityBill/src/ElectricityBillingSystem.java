import java.util.Scanner;

public class ElectricityBillingSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Constants for tariff rates
        final double UNIT_RATE_1 = 5.0; // Rate for first 100 units
        final double UNIT_RATE_2 = 6.5; // Rate for units 101 to 300
        final double UNIT_RATE_3 = 8.0; // Rate for units above 300
        
        // Input the units consumed
        System.out.print("Enter the units consumed: ");
        int unitsConsumed = scanner.nextInt();
        
        // Calculate the bill amount
        double billAmount = 0.0;
        if (unitsConsumed <= 100) {
            billAmount = unitsConsumed * UNIT_RATE_1;
        } else if (unitsConsumed <= 300) {
            billAmount = 100 * UNIT_RATE_1 + (unitsConsumed - 100) * UNIT_RATE_2;
        } else {
            billAmount = 100 * UNIT_RATE_1 + 200 * UNIT_RATE_2 + (unitsConsumed - 300) * UNIT_RATE_3;
        }
        
        // Display the bill details
        System.out.println("Electricity Bill Details:");
        System.out.println("Units Consumed: " + unitsConsumed);
        System.out.println("Bill Amount: Rs." + billAmount);
        
        // Close the scanner
        scanner.close();
    }
}
