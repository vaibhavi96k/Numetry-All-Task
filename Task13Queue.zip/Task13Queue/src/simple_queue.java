public class simple_queue {
    private int[] arr;
    private int front;
    private int rear;

    public simple_queue(int size) {
        arr = new int[size];
        front = -1;
        rear = -1;
    }

    public void enqueue(int element) {
        if (rear == arr.length - 1) {
            System.out.println("Queue is full");
            return;
        }
        rear++;
        arr[rear] = element;
    }

    public int dequeue() {
        if (front == rear) {
            System.out.println("Queue is empty");
            return -1;
        }
        front++;
        return arr[front];
    }

    public boolean isEmpty() {
        return front == rear;
    }

    public boolean isFull() {
        return rear == arr.length - 1;
    }

    public static void main(String[] args) {
        simple_queue queue = new simple_queue(5);
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);

        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
    }
}