import java.util.ArrayDeque;
public class deque_example {
public static void main(String[] args) {
ArrayDeque<Integer> deque = new ArrayDeque<>();
deque.addFirst(10);
deque.addLast(20);
deque.addFirst(5);
deque.addLast(30);
System.out.println(deque.pollFirst()); // 5
System.out.println(deque.pollLast()); // 30
}
}