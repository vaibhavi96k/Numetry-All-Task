import java.util.PriorityQueue;

public class priority_queue{
    public static void main(String[] args) {
        PriorityQueue<Integer> queue = new PriorityQueue<>();

        queue.add(10);
        queue.add(5);
        queue.add(20);
        queue.add(15);

        System.out.println(queue.poll()); // 5
        System.out.println(queue.poll()); // 10
        System.out.println(queue.poll()); // 15
        System.out.println(queue.poll()); // 20
    }
}